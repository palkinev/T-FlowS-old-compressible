
To run unit test, 

  cd build; rake


Single rakefile in "build" directry builds unit test.
Directries to look for Fortran source are given to 
an array "$source_dirs" in the rakefile.


